import cv2
import numpy as np

#Parameters
expected_corners = 3
filename = 'photo_carrefour1.jpg'

# Open image and binarize it
img = cv2.imread(filename)
gray = cv2.cvtColor(img,cv2.COLOR_RGB2GRAY)
blur = cv2.blur(gray,(4,4))
ret,thresh1 = cv2.threshold(blur,124,255,cv2.THRESH_BINARY)

# Morphological processing
kernel = np.ones((4,4), np.uint8)
eroded_mask = cv2.erode(thresh1, kernel, iterations=1)
dilated_mask = cv2.dilate(eroded_mask, kernel, iterations=1)

# Corner detection
dilated_mask = np.float32(dilated_mask)
corners = cv2.goodFeaturesToTrack(dilated_mask, 10,0.01,10)

# Results information
corners = np.intp(corners)
if len(corners) >= expected_corners:
    print("Intersection !")
for i in corners: 
    x, y = i.ravel() 
    print(x,y)
    cv2.circle(img, (x, y),3,255,-1)
cv2.imwrite('out_test.png', img)
